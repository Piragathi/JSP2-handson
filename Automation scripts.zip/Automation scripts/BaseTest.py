import pytest

from Pages.CareersLandingPage import CareersLandingPage
from Pages.FormService import FormService
from Pages.HeaderCarousel import HeaderCarousel
from Pages.MediaLibraryOverviewPage import MediaLibraryOverview
from Pages.NovartisGlobalPipeline import NovartisGlobalPipeline
from utilities.BaseClass import BaseClass

@pytest.mark.usefixtures("setup")
class BaseTest(BaseClass):
    def setup_method(self):
        self.log = self.get_logger()
        self.careers = CareersLandingPage(self.driver)
        self.form = FormService(self.driver)
        self.header = HeaderCarousel(self.driver)
        self. media = MediaLibraryOverview(self.driver)
        self.pipeline = NovartisGlobalPipeline(self.driver)
