from TestData.config import TestData
from Pages.BasePage import BasePage
from selenium.webdriver.common.by import By
import time

class MediaLibraryOverview(BasePage):
    def __init__(self,driver):
        super().__init__(driver)

    MediaLibrary = (By.CSS_SELECTOR, '[href="/news/media-library"]')
    ThirdLevel_Breadcrumbs = (By.CSS_SELECTOR,'li[class="breadcrumb-item"] a[href="/news/media-library"]')
    Default_contentView = (By.XPATH, "//div[contains(@class,'grid_view')]")
    All_Field = (By.XPATH, "//a[normalize-space()='All']")
    Home_BreadCrumb = (By.XPATH,'//li[@class="breadcrumb-item"]/a[normalize-space()="Home"]')
    News_BreadCrumb = (By.XPATH,'//li[@class="breadcrumb-item"]/a[normalize-space()="News"]')
    Page_contents = (By.CSS_SELECTOR,'ul[class="whole-item"] li')
    Pagination = (By.CSS_SELECTOR, 'ul[class="pagination js-pager__items"] li a')
    View_text =(By.XPATH,'//button[@class="toggle_text"]')
    ListView = (By.XPATH,'//div[contains(@class,"list_view")]')
    GridView = (By.XPATH, "//div[contains(@class,'grid_view')]")
    Document_Menu = (By.XPATH,"//a[normalize-space()='Document']")
    pagination_num = (By.XPATH, '//li[@class="page-item "] [normalize-space()="4"]/a')
    currentPage = (By.CSS_SELECTOR, '[class="page-item active"] span')
    forwardbutton = (By.CSS_SELECTOR, '[title="Go to next page"]')
    Backwardbutton = (By.CSS_SELECTOR, '[title="Go to previous page"]')

    def click_element(self,element):
        self.jse_click(element)

    def click_News(self):
        self.Action(self.News)

    def Verify_Isdisplayed(self,element):
        return self.display(element)

    def BreadCrumbs_Isdisplayed(self):
        return self.display_elements(self.BreadCrumbs)

    def Verify_BackgroundColor(self,locator,property):
        return self.get_cssProperty(locator,property)

    def get_contentsLength(self):
        return self.get_elementsLength(self.Page_contents)

    def get_Pagination(self):
        return self.get_elementsLength(self.Pagination)

    def Pagination_Method(self,pagination_length):
        for i in range(pagination_length):
            j = str(i + 1)
            page = self.driver.find_element(By.XPATH,"(//ul[@class='pagination js-pager__items']/li /a)[" + j + "]")
            self.driver.execute_script("arguments[0].click();", page)
            assert self.get_contentsLength() == 12
        return True



    





